package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name="ms1", urlPatterns= {"/servlet2"})
public class Monservlet2 extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)
	         throws ServletException, IOException {
		
		
		
		HttpSession session=request.getSession();
        String pseudo = request.getParameter("pseudo");
        String password = request.getParameter("password");
        
               
        if ( pseudo==null) {
        	this.getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
           
        }else {
			List<User> liste = (List<User>) session.getAttribute("liste");
			
			for(User u : liste){
				
				if(pseudo.equals(u.getPseudo()) && password.equals(u.getPassword())){
		        	this.getServletContext().getRequestDispatcher("/Acceuil.jsp").forward(request, response);

					
				}
			}
			
			request.setAttribute("erreur", "Vous n'êtes pas enregistrer.");
        	this.getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
		
			
		}
		
	}
	
}
